class Student:
    average_marks=0
    grade=''

    def __init__(self,name,roll,python_mark,TOC_mark,OS_mark):
        self.name=name
        self.roll=roll
        self.roll=roll
        self.python_mark=python_mark
        self.TOC_mark=TOC_mark
        self.OS_mark=OS_mark

    def moderate_marks(self,grace_mark):
        if self.python_mark<100:
            self.python_mark=self.python_mark+grace_mark

        if self.TOC_mark<100:
            self.TOC_mark=self.TOC_mark+grace_mark

        if self.OS_mark<100:
            self.OS_mark=self.OS_mark+grace_mark
        return  self.python_mark,self.TOC_mark,self.OS_mark

    
    def average(self):
        m1,m2,m3=self.moderate_marks(10)
        average_marks=(m1+m2+m3)/3
        return average_marks

    def get_grade(self):
        marks=self.average()
        if marks<40:
            self.grade='D(Fail)'
        elif 40<=marks<60:
            self.grade='C'
        elif 60<=marks<80:
            self.grade='B'
        elif 80<=marks:
            self.grade='A'
        return self.grade

def data():
    name=input('enter name')
    roll=int(input('enter roll'))
    m1=int(input('enter python mark'))
    m2=int(input('enter TOC mark'))
    m3=int(input('enter OS mark'))
    m=[m1,m2,m3]
    s=['python_mark','TOC_mark','OS_mark']
    dt1=dict(zip(s,m))
    info=['name','roll','marks']
    info2=[name,roll,dt1]
    dt2=dict(zip(info,info2))
    return dt2

li=[]
for i in range(4):
    print('student',(i+1))
    dt=data()
    li.append(dt)

for i in li:
    student=i
    Name=student['name']
    Roll_Number=student['roll']
    Python=student['marks']['python_mark']
    TOC=student['marks']['TOC_mark']
    OS=student['marks']['OS_mark']
    s1 = Student(Name, Roll_Number, Python, TOC, OS)
    print('grade recieved by ',Name,' is ',s1.get_grade())