import pickle
def data():
    name=input('enter name')
    roll=int(input('enter roll'))
    m1=int(input('enter python mark'))
    m2=int(input('enter TOC mark'))
    m3=int(input('enter OS mark'))
    m=[m1,m2,m3]
    s=['python mark','TOC mark','OS mark']
    dt1=dict(zip(s,m))
    info=['name','roll','marks']
    info2=[name,roll,dt1]
    dt2=dict(zip(info,info2))
    return dt2

li=[]
for i in range(4):
    print('student',(i+1))
    dt=data()
    li.append(dt)

f=open('studentData','wb')
pickle.dump(li,f)
f.close()



